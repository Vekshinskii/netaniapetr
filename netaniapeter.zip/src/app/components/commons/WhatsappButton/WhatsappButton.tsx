'use client';
import Link from 'next/link';
import React from 'react';

type WhatsappButtonProps = {
    message?: string;
    className?: string;
    svgClassName?: string;
    style?: React.CSSProperties;
    svgStyle?: React.CSSProperties;
    size?: number;

    openInNewTab?: boolean;
    onClick?: () => void;
};

export default function WhatsappButton({
                                           message,
                                           className,
                                           svgClassName,
                                           style,
                                           svgStyle,
                                           size = 60,
                                           openInNewTab = false,
                                           onClick,
                                       }: WhatsappButtonProps) {

    const href = message
        ? `https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUM}?text=${encodeURIComponent(message)}`
: `https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUM}`;

    return (
        <Link
            href={href}
            aria-label="WhatsApp"
            className={['wa_link', className].filter(Boolean).join(' ')}
            style={style}
            target={openInNewTab ? '_blank' : undefined}
            rel={openInNewTab ? 'noopener noreferrer' : undefined}
            onClick={onClick}
        >
            <svg
                className={['whatsapp', svgClassName].filter(Boolean).join(' ')}
                style={{ width: size, height: size, ...svgStyle }}
                viewBox="0 0 70 70"
                xmlns="http://www.w3.org/2000/svg"
            >
                <path
                    d="M35 68.995C52.7451 70.1546 70 55.5748 70 34.4975C70 15.5886 54.2078 0 35 0C15.7922 0 0 15.4456 0 34.4975C0 44.0138 4.22353 51.1955 5.92941 53.7118C6.21176 54.2529 6.26667 54.8907 6.06667 55.4782L1.35686 69.5014C1.25882 69.799 1.5451 70.0812 1.84706 69.9768L16.7804 64.8669C17.3882 64.6582 18.051 64.7084 18.6196 65.0099C21.8471 66.7145 27.698 68.5196 35 68.995Z"
                    fill="currentColor"
                />
                <path
                    d="M25.8822 32.0816C26.2783 30.7867 27.7528 30.8718 28.6273 29.3759C28.8469 28.9971 29.2861 28.0849 28.6273 24.7376C27.8312 20.6868 27.2822 17.8999 25.0979 17.007C23.9881 16.5509 22.9371 16.7867 21.9606 17.007C18.0116 17.8961 16.2665 21.6183 16.0783 22.0319C15.4234 23.4852 15.294 24.8458 15.294 25.8972C15.2861 31.3626 18.7332 38.0612 23.9214 43.2909C28.4351 47.8403 32.9332 49.9468 36.0783 51.4079C37.2116 51.9336 39.8979 53.1241 43.5293 53.7271C46.7802 54.2682 48.494 53.959 49.4116 53.7271C50.4665 53.4604 51.992 53.0739 53.3332 51.7944C54.8744 50.3218 56.2194 47.6238 55.294 45.61C55.1371 45.2699 55.7528 45.4477 52.5489 43.2909C49.5645 41.2809 48.2704 40.6316 47.4508 40.5852C45.6783 40.4847 44.2508 41.4974 43.9214 41.7448C42.0665 43.1401 42.1606 44.9065 40.7842 45.2235C40.1214 45.3781 39.5567 45.0959 38.4312 44.4504C35.8508 42.9739 34.5606 42.2356 32.941 40.9717C30.4665 39.0391 29.1998 38.038 27.843 36.3334C26.5293 34.6829 25.494 33.3494 25.8822 32.0816Z"
                    fill="white"
                />
            </svg>
        </Link>
    );
}