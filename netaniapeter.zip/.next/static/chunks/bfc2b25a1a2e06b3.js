__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/cc3bcf3a7fdf36a3.js",
  "static/chunks/turbopack-80bd7efdc7b5227d.js"
])
