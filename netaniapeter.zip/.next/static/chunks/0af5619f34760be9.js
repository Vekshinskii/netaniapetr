__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/cc3bcf3a7fdf36a3.js",
  "static/chunks/turbopack-527d906c50002a51.js"
])
