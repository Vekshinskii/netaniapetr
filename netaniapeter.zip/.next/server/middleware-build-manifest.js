globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/cc3bcf3a7fdf36a3.js",
      "static/chunks/turbopack-527d906c50002a51.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/cc3bcf3a7fdf36a3.js",
      "static/chunks/turbopack-80bd7efdc7b5227d.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c62b4372c26b460f.js",
    "static/chunks/89fec6e6de8a2578.js",
    "static/chunks/202abb9aed9e828b.js",
    "static/chunks/2f15b6b92b47217c.js",
    "static/chunks/turbopack-f1a47e610159b3b8.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];