var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a69459cc._.js")
R.c("server/chunks/node_modules_next_dist_77fd8386._.js")
R.c("server/chunks/node_modules_next_dist_03a3c8f9._.js")
R.c("server/chunks/[root-of-the-server]__b218749b._.js")
R.m(15934)
R.m(73932)
module.exports=R.m(73932).exports
